<!-- EACH PRODUCT CONTAINER STARTS FROM HERE -->

<div class="eachproductContainer mainContainer goToScroll">

      <input type="hidden" value=""  class="cart_id"  />
      <input type="hidden" value="<?=$product->ProductID?>" class="product_id"  />
      <input type="hidden" value="<?=$product->ManufactureID?>" class="manfactureid"  />
      <input type="hidden" value="<?=$product->LabelsPerSheet?>" class="LabelsPerSheet"  />
      <input type="hidden" value="" class="digitalprintoption"  />
      <input type="hidden" value="<?=$min_qty?>"  class="minimum_quantities"  />
      <input type="hidden" value="<?=$max_qty?>"  class="maximum_quantities"  />
      <input type="hidden" value="0" data-qty="0"  id="uploadedartworks_<?=$product->ProductID?>"  />
      <input type="hidden" value="<?=$product->Printable?>"  class="PrintableProduct"  />
      <input type="hidden" value="<?=$product->ProductCategoryName?>" class="category_description"  />

    <div class="MaterialWhiteBg productHover" id="MaterialCenterContentActiveSelector<?php echo $materialCounter;?>">
        <?php
        /*
        if($favouriteProductslisting == 'yes')
        {
            echo "<p><img src='".Assets."images/icons/favourites.png"."' class='favouriteIcon' /></p>";
        }
        */
        ?>
        
        <div class="showArrow"></div>
        <div class="MaterialCenterContentOuter">
            <div class="MaterialCenterContentOuterArrow"></div>
            <div class="MaterialCenterContentInner">

                <div class="row RowDefault">
                    <div class="MaterialCenterContentImage">
                        <img src="<?php echo $mat_image;?>" alt="" title="" class="product_material_image">
                    </div>
                    <div class="MaterialCenterContentDetail">
                        <p>
                            <span class="product-title"><?php echo $group_name;?></span> <?php echo $materialDescription;?><br><br>
                            Code: <?php echo $product->ManufactureID;?>, <?php echo $product->LabelsPerSheet." ".$product->Shape." Labels per";?> A4 sheet. Label size (mm): <?php echo $product->pwidth;?> x <?php echo $product->pheight;?>.
                            <br><br>
                            <a href="javascript:;" class="technical_specs" id="<?=$product->ProductID?>" data-toggle="modal" data-target="#MaterialModalPopup" data-original-title="Technial Specification"> Material Specification&nbsp;<i class="fa fa-info-circle" aria-hidden="true"></i> </a>
                            &nbsp;
                            
                            <?php
                                // if($favouriteProductslisting == 'no')
                                // {
                                    $favourite_icon = "fa fa-heart-o";
                                    if($this->session->userdata('logged_in') == 1)
                                    {
                                        $check = $this->home_model->checkProductFavouriteStatus($this->session->userdata("filterUses"), $product->ProductID, $this->session->userdata("userid"));
                                        if($check->numRows == 1 )
                                        {   
                                            $favourite_icon = "fa fa-heart";
                                        }
                                    ?>
                                        <a href="javascript:void(0);" onclick="favourite_unfavourite(this,'<?php echo $categoryId;?>', '<?php echo $sheetRollType;?>', '<?php echo $product->ProductID;?>');" class="MaterialSaveSearchIcon pull-right half-circle" >
                                            <i class="<?php echo $favourite_icon;?>"></i>
                                        </a>
                                    <?php
                                    }
                                // }
                            ?>

                        </p>
                    </div>
                </div>
                <div class="row RowDefault MaterialContentBottom">
                    <div class="MaterialSampleAdded">
                        <button class="btn rsample" data-  data-toggle="modal" data-target="#SampleModal">ADD SAMPLE TO BASKET</button>
                    </div>
                    <div class="MaterialContentInlineListing">
                        <ul>
                            <li>
                                <img onerror='imgError(this);' src="<?=Assets?>images/check-circle.png" class="TickSVG" />
                                <div class="MaterialContentProductDescription">
                                    <span class="MaterialContentBottomBold">DRY EDGE</span><br>
                                    <span class="MaterialContentBottomNormal">PRODUCT <a href="javascript:void(0);"><i class="fa fa-info-circle"></i></a> </span>
                                </div>
                            </li>
                            <li>
                                <img onerror='imgError(this);' src="<?=Assets?>images/check-circle.png" class="TickSVG" />
                                <div class="MaterialContentProductDescription">
                                    <span class="MaterialContentBottomBold">QUALITY ASSURANCE</span><br>
                                    <span class="MaterialContentBottomNormal">GUARANTEE</span>
                                </div>
                            </li>
                            <li>
                                <img onerror='imgError(this);' src="<?=Assets?>images/check-circle.png" class="TickSVG" />
                                <div class="MaterialContentProductDescription">
                                    <span class="MaterialContentBottomBold">LASER PRINTER</span><br>
                                    <span class="MaterialContentBottomNormal">COMPATIBLE&nbsp;<a href="javascript:void(0);"><i class="fa fa-info-circle"></i></a> </span>
                                </div>
                            </li>
                            <li>
                                <img onerror='imgError(this);' src="<?=Assets?>images/check-circle.png" class="TickSVG" />
                                <div class="MaterialContentProductDescription">
                                    <span class="MaterialContentBottomBold">INKJET PRINTER</span><br>
                                    <span class="MaterialContentBottomNormal">COMPATIBLE&nbsp;<a href="javascript:void(0);"><i class="fa fa-info-circle"></i></a> </span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="row RowDefault">
                    <div class="MaterialViewPrices">
                        <button class="btn" dataPriceBox='add_to_cart_<?php echo $materialCounter;?>' dataMaterialCounter='<?php echo $materialCounter;?>' datatotalMaterials='<?php echo $allProductsSum;?>'>View Prices  <i class="fa fa-calculator"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- EACH PRICE BOX STARTS FROM HERE -->
    <div class="MaterialProductPriceMain">
        
        <div class="aa_loader" class="white-screen" style="position: absolute;top: 0;right: 0;width: 100%;z-index: 999;height: 100%; display: none;background: #FFF; opacity: 0.8">
            <div class="text-center" style="margin: 80px auto!important;background: rgba(255,255,255,.9) none repeat scroll 0 0;padding: 10px;border-radius: 5px;border: solid 1px #CCC;">
                <img onerror="imgError(this);" src="<?=Assets?>images/loader.gif" class="image" style="width:139px; height:29px; " alt="AA Labels Loader">
            </div>
        </div>

        <?php include "selected_material_prices.php";?>
    </div>
    <!-- EACH PRICE BOX STARTS FROM HERE -->
</div>
<!-- EACH PRODUCT CONTAINER ENDS FROM HERE -->