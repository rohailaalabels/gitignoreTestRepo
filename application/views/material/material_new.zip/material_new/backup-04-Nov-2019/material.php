
    <link rel='stylesheet' href='<?=Assets?>css/1200px-material-page.css'>

    <style>
        .labels-form input.error {
            background: rgb(251, 227, 228);
            border: 1px solid #fbc2c4;
            color: #8a1f11;
        }

        .labels-form label.error {
            color: #8a1f11;
            display: inline-block;
            font-weight: normal;
        }

        .top-head .lng-btn {
            display: inline-block;
            float: right;
            height: 30px;
            margin-left: 0px;
        }

        .top-head .lng-btn a {
            background: none 0 0;
            border-radius: 4px;
            cursor: pointer;
            display: inline-block;
            margin: 0;
            outline: 0 none;
            padding: 1px;
            text-align: center;
        }

        .top-head .lng-btn img {
            margin: 0px 0px 0px 26px;
        }
        .favouriteIcon
        {
            width: 22px;
            position: absolute;
            z-index: 1;
            top: 3px;
            right: 11px;
        }

        @media only screen and (min-width: 1200px) {
            .logoadjustements {
                width: 23% !important;
            }
        }

        @media only screen and (min-width: 1200px) {
            .searchboxadjustment {
                width: 27%;
            }
        }

        @media only screen and (min-width: 1200px) {
            .searchboxadjustment div {
                width: 100%;
            }
        }
    </style>
    <link href="<?=Assets?>css/mat-sep-2017.css" rel="stylesheet">
    <script src="<?=Assets?>labelfinder/js/jquery-ui.js"></script>

    <style>
        .giveMeEllipsis {
            text-overflow: ellipsis;
            word-wrap: break-word;
            overflow: hidden;
            max-height: 3.6em;
            line-height: 1.8em;
        }
        .dropzone .dz-preview {
            margin: 0px;
        }
        .dropzone .dz-preview .dz-image {
            display: block;
            border-radius: none;
            height: 50px;
            overflow: hidden;
            position: relative;
            width: 50px;
            z-index: 10;
        }
        .dropzone .dz-preview .dz-success-mark svg, .dropzone .dz-preview .dz-error-mark svg {
            display: block;
            height: 25px;
            width: 25px;
        }
        .dropzone .dz-preview.dz-image-preview .dz-details {
            display: none;
        }
        .dropzone .btn {
            margin-top: 10px;
            cursor: pointer;
        }
        .mat-ch .detail .form-control {
            padding: 6px 6px !important;
        }
        .discount_price {
            color: black !important;
            font-size: 16px !important;
            text-decoration: line-through !important;
            display: inline !important;
        }
        .mat_class {
            margin: 5px;
        }
        select option:disabled {
            background: #dedede;
        }
        .ovFl thead {
            background: #17b1e3 none repeat scroll 0 0;
            color: white;
        }
        .productdetails .phead {
            font-size: 12px;
            line-height: normal;
        }
        .dm-box .dm-selector .btn {
            font-size: 13px;
            border: 1px solid #e5e5e5;
            color: #666;
            text-align: left;
        }
        .dm-box .dm-selector .fa {
            position: absolute;
            right: 10px;
            top: 11px;
        }
        .dm-box .dm-selector .dropdown-menu a {
            color: #666;
            cursor: pointer;
        }
        .dm-selector .tooltip {
            font-size: 13px !important;
            width: 290px !important;
        }
        .dm-selector .tooltip.left .tooltip-arrow {
            border-left-color: #FEF7D8 !important;
        }
        .dm-selector .tooltip.right .tooltip-arrow {
            border-right-color: #FEF7D8 !important;
        }
        .dm-selector .tooltip.top .tooltip-arrow {
            border-top-color: #FEF7D8 !important;
        }
        .dm-selector .tooltip.bottom .tooltip-arrow {
            border-bottom-color: #FEF7D8 !important;
        }
        .dropdown-menu li .tooltip .tooltip-inner {
            background-color: #FEF7D8;
            border-radius: 4px;
            color: #454545;
            max-width: 381px;
            padding: 8px 15px;
            text-align: justify;
            text-decoration: none;/*  font-style: italic;*/
        }
        .dm-selector.tooltip.in {
            opacity: 1;
        }
        .tooltip.right .tooltip-arrow {
            border-right-color: #fff8dc !important;
        }
        .productdetails .input-group .form-control {
            height: 38px !important;
        }
        .sweet-alert {
            box-shadow: 0 0 20px;
        }
        .mat-may-2017 section article.mat-detail .specs a.technical_specs {
            top: 0px;
        }
        .mat-may-2017 section article.mat-tabs .ofq {
            margin-top: 140px;
        }
        .flexcontainer {
            display: flex;
        }
        .flexcontainer .why-seal {
            /*position: absolute;

                right: 0px;

                bottom: 0px;*/

        }
        .flexcontainer .why-seal img {
            margin: 0 auto;
        }
        .table.printer {
            font-family: "Open Sans", Helvetica, Arial, sans-serif;
        }
        .sort-filters:before, .sort-filters:after {
            content: " ";
            display: table;
            clear: both;
        }
        .filterBg .labels-form label {
            margin-bottom: 0px;
        }
        .filterBg {
            padding: 15px 10px !important;
            margin-bottom: 0px;
            background: #17b1e3;
            border-radius: 0;
        }
        .filterBg h4 {
            color: #fff;
        }
        .mat-ch {
            border: 0;
        }
        .pr-table {
            width: 100%;
        }
        .pr-table td {
            padding: 0 15px;
            border-right: 1px solid;
            text-align: center;
        }
        .pr-table td:first-child {
            padding-left: 0;
        }
        .pr-table td:last-child {
            border: 0;
        }
        .printer_top_div table tr td {
            padding: 0 !important;
            vertical-align: top;
        }
        .printer_top_div {
            border-left: 1px solid #333;
        }
        .price_promise h1 {
            font-size: 20px;
            font-weight: bold;
            margin: 0 0 10px 0 !important;
        }
        .euro_text_top {
            height: 70px;
            margin-top: 30px;
        }
        .euro_thumbnail {
            margin-top: -25px !important;
        }
        @media (min-width:1024px) {
            .plainprice_box {
                margin-top: -20px;
            }
            .mat-may-2017 section article.mat-tabs .service {
                margin-top: -20px;
                margin-left: -140px !important;
            }
        }
        .plainprice_box .halfprintprice .phead {
            font-weight: bold;
        }
        .filterBg.desktop-view {
            margin: -15px;
            margin-top: 0px;
            border-top: 5px solid #e0e0e0;
            background: #fff;
        }
        .filterBg.desktop-view.non_euro {
            margin-top: 5px;
        }
        
        .filterContainer
        {
            display: inline-flex;
            flex-direction: column-reverse;
            transition: all 2s;
        }
    </style>

    <style>
        @media screen and (min-width:768px)
        {
            .price_promise_div {
                margin-top: -20px;
                margin-bottom: 10px;
            }
        }
        @media screen and (min-width: 1024px)
        {
            .price_promise_div {
                margin-top: -55px;
                margin-bottom: 10px;
            }
        }
    </style>

<div class="">
    <div class="container m-t-b-8">
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <ol class="breadcrumb  m0">
                    <?=$this->home_model->genrate_breadcrumb('material');?>
                    <li class="active">
                        <?=$details['CategoryName']?>
                    </li>
                </ol>
            </div>
        </div>
    </div>
</div>
<div class="bgGray" style="padding-top:0;">

    <div class="MaterialSeprator">&nbsp;</div>

    <!--  Material Page Content Start  -->
    <div class="container"> 
        <!--  Material Page Left Filter Start  -->
        <div class="MaterialFilterMain">
            <div class="MaterialFilterBackButton">
                <a href="javascript:;">
                    <i class="fa fa-arrow-circle-left"></i> Back to Shape and Size
                </a>
            </div>

            <div class="switchToggle MaterialFilterToggleButton">
                <input type="checkbox" id="switch" onclick="FilterSwapping();" value="sbProduct">
                <label for="switch">Toggle</label>
            </div>
      
            <div class="inputhiddens">
                    <input type="hidden" name="categoryId" class="categoryId" value="<?php echo $categoryId;?>">
                    <input type="hidden" name="printingType" class="printingType" value="Sheets">
                    <input type="hidden" name="productid" class="productid" value="<?php echo $productid;?>">
                    <input type="hidden" name="filterUses" class="filterUses" value="byProduct">
            </div>

            <div id="FilterContainer" class="159">
                
                <div class="RowDefault pull-left MaterialByProducts">
                    
                    <div class="disablePopupByProduct"></div>

                    <div class="MaterialFilterHeader text-center">Filter by Products</div>
                    <div class="MaterialWhiteBg MaterialFilter">
                        
                        <div class="MaterialFilterTitle FBUResultFound  text-center"></div>

                        <div class="MaterialSaveAndReset">
                            <div class="MaterialSaveSearch MaterialSaveSearchByProduct pull-left">
                                <a href="javascript:;">
                                    <?php
                                        $userID = $this->session->userdata('userid');
                                        if( isset($userID) && $userID != '' )
                                        {?>
                                            <input type="checkbox" class="favouriteProducts favouritebyProducts" onclick="filterbyProducts();">
                                            <span class="totalFavouriteCounts">
                                                <?php
                                                    if($totalFavouritesByProduct->numRows > 0){
                                                        echo $totalFavouritesByProduct->numRows;
                                                    }else{
                                                        echo '0';
                                                    }
                                                ?>
                                            </span>
                                            <i class="fa fa-heart-o"></i>
                                        <?php
                                        }
                                    ?>

                                </a>
                            </div>
                            <div class="MaterialResetFilter pull-right"><a href="javascript:;" onclick="resetByProducts()" ><i class="fa fa-sync-alt"></i> Reset </a></div>
                        </div>
                        <div class="clear"></div>
                        <div class="MaterialFilterListing">
                            
                            <ul>

                                 <!-- STATIC FILTERS OPTIONS STARTS FROM HERE -->
                                <li>
                                    <a href="javascript:;" class=" MaterialFilterLeftProducts MaterialFilterListSingle">
                                        <div class="MaterialFilterLeft  pull-left">Adhesive Type<span>(<?php echo count($adhesives);?>)</span></div>
                                        <div class="MaterialFilterRight pull-right"><i class="fa fa-chevron-right"></i>
                                        </div>
                                    </a>
                                    <div class="MaterialFilterDropRight FBPParent">
                                        <div class="MaterialDropRightHeader">
                                            <div class="MaterialDropRightTitle pull-left">
                                                <h3 class="TitleH3">Adhesive Type<span>- Select 1 or more options.</span></h3>
                                            </div>
                                            <div class="MaterialDropRightClose pull-right" aria-label="Close"><a href="javascript:;">Close</a></div>
                                        </div>
                                        <div class="MaterialDropRightBody">
                                                <?php
                                                if(isset($adhesives) && $adhesives != '' && count($adhesives) > 0){
                                                    foreach ($adhesives as $key => $adhesive){
                                                        if($key % 3 == 0){echo "<div style='clear:both;'></div>";}?>
                                                        <div class="MaterialDropRightBodyCheckbox">
                                                            <label class="DropRightCheckBox"><?php echo $adhesive->adhesive;?>
                                                                 <input type="checkbox"  data-filter-type = 'adhesive' name="FBAP" value="<?= "'".$adhesive->adhesive."'"; ?>" class="FBAP">

                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                    <?php
                                                    }
                                                }
                                                ?>
                                        </div>
                                        <div class="MaterialDropRightFooter">

                                            <a class="btn orange clearBtn clearBtnByProduct" href="javascript:;" onclick="clearFilterByAT(this)">Clear</a>
                                            <a class="btn ApplyBtn ApplyBtnByProduct" href="javascript:;" onclick="filterbyProducts()">Apply</a>


<!--                                            <a class="btn orange clearBtnByProduct" href="javascript:;">Clear</a>-->
<!--                                            <a class="btn ApplyBtn" href="javascript:;">Apply</a>-->
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <a href="javascript:;" class=" MaterialFilterLeftProducts MaterialFilterListSingle">
                                        <div class="MaterialFilterLeft  pull-left">Printer Compatibility <span>(<?php echo count($printers);?>)</span></div>
                                        <div class="MaterialFilterRight pull-right"><i class="fa fa-chevron-right"></i>
                                        </div>
                                    </a>
                                    <div class="MaterialFilterDropRight FBPParent">
                                        <div class="MaterialDropRightHeader">
                                            <div class="MaterialDropRightTitle pull-left">
                                                <h3 class="TitleH3">Printer Compatibility <span>- Select 1 or more options.</span></h3>
                                            </div>
                                            <div class="MaterialDropRightClose pull-right" aria-label="Close"><a href="javascript:;">Close</a></div>
                                        </div>
                                        <div class="MaterialDropRightBody">
                                                <?php
                                                if(isset($printers) && $printers != '' && count($printers) > 0){
                                                    foreach ($printers as $key => $printer){
                                                        if($key % 3 == 0){echo "<div style='clear:both;'></div>";}?>
                                                        <div class="MaterialDropRightBodyCheckbox">
                                                            <label class="DropRightCheckBox"><?php echo $printer->SpecText7;?>
                                                                <input type="checkbox" data-filter-type = 'printer' name="FBAP" value="<?= "'".$printer->SpecText7."'"; ?>" class="FBAP">

                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                    <?php
                                                    }
                                                }
                                                ?>
                                        </div>
                                        <div class="MaterialDropRightFooter">

                                            <a class="btn orange clearBtn clearBtnByProduct" href="javascript:;" onclick="clearFilterByPC(this)">Clear</a>
                                            <a class="btn ApplyBtn ApplyBtnByProduct" href="javascript:;" onclick="filterbyProducts()">Apply</a>

<!--                                            <a class="btn orange clearBtnByProduct" href="javascript:;">Clear</a>-->
<!--                                            <a class="btn ApplyBtn" href="javascript:;">Apply</a>-->
                                        </div>
                                    </div>
                                </li>
                                <!-- STATIC FILTERS OPTIONS ENDS FROM HERE -->


                                <!-- DYNAMIC FILTERS + COLOURS OPTIONS STARTS FROM HERE -->
                                <?php
                                if(isset($materials) && $materials != '' && count($materials) > 0){
                                    foreach($materials as $keyParent => $material){?>
                                        <li>
                                            <a href="javascript:;" class="MaterialFilterLeftProducts MaterialFilterListSingle">
                                                <div class="MaterialFilterLeft pull-left"><?php echo $material->M_group_name;?> <span>(<?php echo $material->totalColours;?>)</span> </div>
                                                <div class="MaterialFilterRight pull-right"><i class="fa fa-chevron-right"></i>
                                                </div>
                                            </a>
                                            <div class="MaterialFilterDropRight FBPParent">
                                                <div class="MaterialDropRightHeader">
                                                    <div class="MaterialDropRightTitle pull-left">
                                                        <h3 class="TitleH3"><?php echo $material->M_group_name;?> <span>- Select 1 or more options.</span></h3>
                                                    </div>
                                                    <div class="MaterialDropRightClose pull-right" aria-label="Close"><a href="javascript:;">Close</a></div>
                                                </div>
                                                <div class="MaterialDropRightBody">
                                                        <?php
                                                        $materialColors = explode($arraySeprator, $material->materialColors);

                                                        $materialColorsGrouped = array();
                                                        foreach ($materialColors as $keygrouped => $value) {
                                                            array_push($materialColorsGrouped, "'".$value."'");
                                                        }
                                                        $imploded = implode(',',$materialColorsGrouped);
                                                        $getMaterialByUse = $this->db->query("SELECT material_code,filter_color  FROM material_tooltip_info WHERE mbl_material_group_abr = '".$material->M_abreviation."' AND filter_color IN(".$imploded.")   ORDER BY FIELD(filter_color, ".$imploded.") ");
                                                        $eachColorMaterials = $getMaterialByUse->result();


                                                        if(isset($materialColors) && $materialColors != '' && count($materialColors) > 0){
                                                            foreach ($materialColors as $keyMaterials => $materialColor){
                                                                $productManufactureCodes = "";
                                                                if($keyMaterials % 3 == 0){echo "<div style='clear:both;'></div>";}?>
                                                                <div class="MaterialDropRightBodyCheckbox">
                                                                    <label class="DropRightCheckBox"><?php echo $materialColor;?>
                                                                        
                                                                        <?php
                                                                        
                                                                        $ProductMaterial = "";
                                                                        if(count($eachColorMaterials) > 0)
                                                                        {
                                                                            $eachMatCount = 0;
                                                                            foreach( $eachColorMaterials  as $keyEachMaterial => $eachColorMaterial )
                                                                            {
                                                                                if($eachColorMaterial->filter_color == $materialColor)
                                                                                {
                                                                                    if($eachMatCount != 0){$productManufactureCodes .= ',';}
                                                                                    $material_code = $this->home_model->getmaterialcode($products[0]->ManufactureID);
                                                                                    $productManufactureCodes .= "'".(str_replace($material_code, "", $products[0]->ManufactureID)).$eachColorMaterial->material_code."'";
                                                                                    $eachMatCount++;
                                                                                }
                                                                            }
                                                                        }
                                                                        ?>
                                                                        <input type="checkbox" name="FBP" value="<?php echo $productManufactureCodes;?>" class="FBP">
                                                                        <span class="checkmark"></span>
                                                                    </label>
                                                                </div>
                                                            <?php
                                                            }
                                                        }
                                                        ?>
                                                </div>
                                                <div class="MaterialDropRightFooter">
                                                    <a class="btn orange clearBtn clearBtnByProduct" href="javascript:;" onclick="clearFilterByProducts(this)">Clear</a>
                                                    <a class="btn ApplyBtn ApplyBtnByProduct" href="javascript:;" onclick="filterbyProducts()">Apply</a>
                                                </div>
                                                <div style="clear: both;"></div>
                                            </div>
                                        </li>
                                    <?php
                                    }
                                }
                                ?>
                                <!-- DYNAMIC FILTERS + COLOURS OPTIONS ENDS FROM HERE -->

                                <!-- SORT BY STATIC FILTERS OPTIONS STARTS FROM HERE -->
                                <li>
                                    <a href="javascript:;" class=" MaterialFilterLeftProducts MaterialFilterListSingle">
                                        <div class="MaterialFilterLeft  pull-left">Sort By </div>
                                        <div class="MaterialFilterRight pull-right"><i class="fa fa-chevron-right"></i>
                                        </div>
                                    </a>
                                    <div class="MaterialFilterDropRight FBPParent">
                                        <div class="MaterialDropRightHeader">
                                            <div class="MaterialDropRightTitle pull-left">
                                                <h3 class="TitleH3">Sort By <span>- Select 1 or more options.</span></h3>
                                            </div>
                                            <div class="MaterialDropRightClose pull-right" aria-label="Close"><a href="javascript:;">Close</a></div>
                                        </div>
                                        <div class="MaterialDropRightBody">
                                                <?php
                                                /*
                                                if(isset($printers) && $printers != '' && count($printers) > 0){
                                                    foreach ($printers as $key => $printer){?>
                                                        <div class="MaterialDropRightBodyCheckbox">
                                                            <label class="DropRightCheckBox"><?php echo $printer->SpecText7;?>
                                                                <input type="checkbox" checked="checked">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                    <?php
                                                    }
                                                }
                                                */
                                                ?>
                                        </div>
                                        <div class="MaterialDropRightFooter">
                                            <a class="btn orange clearBtnByProduct" href="javascript:;">Clear</a>
                                            <a class="btn ApplyBtn" href="javascript:;">Apply</a>
                                        </div>
                                    </div>
                                </li>
                                <!-- SORT BY STATIC FILTERS OPTIONS ENDS FROM HERE -->
                            </ul>

                        </div>
                    </div>
                </div>
                
                <div class="RowDefault MaterialFilterbyUse">
                    
                    <div class="disablePopupByUse RollMaterialWhiteBgDisabled"></div>

                    <div class="MaterialFilterHeader text-center">Filter by Use</div>
                    <div class="MaterialWhiteBg MaterialFilter">
                        
                        <div class="MaterialFilterTitle FBUResultFound text-center"></div>

                        <div class="MaterialSaveAndReset">
                            <div class="MaterialSaveSearch MaterialSaveSearchByUse pull-left">
                                <a href="javascript:;">
                                    <?php
                                        $userID = $this->session->userdata('userid');
                                        if( isset($userID) && $userID != '' )
                                        {?>
                                            <input type="checkbox" class="favouriteProducts favouriteByUse" onclick="filterbyUse();">
                                            <span class="totalFavouriteCounts">
                                                <?php
                                                    if($totalFavouritesByUse->numRows > 0){
                                                        echo $totalFavouritesByUse->numRows;
                                                    }else{
                                                        echo '0';
                                                    }
                                                ?>
                                            </span>
                                            <i class="fa fa-heart-o"></i>
                                        <?php
                                        }
                                    ?>
                                </a>
                            </div>
                            <div class="MaterialResetFilter pull-right"><a href="javascript:;" onclick="resetByUse()" ><i class="fa fa-sync-alt"></i> Reset </a></div>
                        </div>

                        

                        <div class="clear"></div>
                        <div class="MaterialFilterListing">
                            <ul>
                                

                                <?php
                                if(isset($materialsByUses) && $materialsByUses != '' && count($materialsByUses) > 0){
                                    foreach ($materialsByUses as $key1 => $materialsByUse){?>
                                        
                                        <li>

                                            <a href="javascript:;" class="MaterialFilterLeftUse MaterialFilterListSingle">
                                                <div class="MaterialFilterLeft  pull-left"><?php echo $materialsByUse->category;?> <span>(<?php echo $materialsByUse->totalSubCategories;?>)</span> </div>
                                                <div class="MaterialFilterRight pull-right"><i class="fa fa-chevron-right"></i>
                                                </div>
                                            </a>

                                            <div class="MaterialFilterDropRight FBUParent">
                                                <div class="MaterialDropRightHeader">
                                                    <div class="MaterialDropRightTitle pull-left">
                                                        <h3 class="TitleH3"><?php echo $materialsByUse->category;?> </h3>
                                                    </div>
                                                    <div class="MaterialDropRightClose pull-right" aria-label="Close"><a href="javascript:;">Close</a></div>
                                                </div>
                                                <div class="MaterialDropRightBody">
                                                        <?php
                                                        $counter = 0;
                                                        $getMaterialByUse = $this->db->query("SELECT * FROM filter_by_use_sub WHERE categoryid = $materialsByUse->ID ");
                                                        $resultsSubs = $getMaterialByUse->result();
                                                        if(isset($resultsSubs) && $resultsSubs != '' && count($resultsSubs) > 0){
                                                            foreach ($resultsSubs as $key2 => $resultsSub){
                                                                if($counter % 3 == 0){echo "<div style='clear:both;'></div>";}?>
                                                                <div class="MaterialDropRightBodyCheckbox">
                                                                    <label class="DropRightCheckBox"><?php echo $resultsSub->name;?>
                                                                        <?php
                                                                        $productManufactureCodes = "";
                                                                        $ProductMaterial = "";
                                                                        if(count(explode(",",$resultsSub->mat_sheet)) > 0)
                                                                        {
                                                                            foreach( explode(",",$resultsSub->mat_sheet)  as $key => $eachProductMat1)
                                                                            {
                                                                                if($key != 0)
                                                                                {
                                                                                    $productManufactureCodes .= ',';
                                                                                }
                                                                                $material_code = $this->home_model->getmaterialcode($products[0]->ManufactureID);
                                                                                $productManufactureCodes .= "'".(str_replace($material_code, "", $products[0]->ManufactureID)).$eachProductMat1."'";
                                                                                
                                                                            }
                                                                        }
                                                                        ?>
                                                                        <input type="radio" name="FBU" value="<?php echo $productManufactureCodes;?>" class="FBU" >
                                                                        <span class="checkmark"></span>
                                                                    </label>
                                                                </div>
                                                            <?php
                                                            $counter++;
                                                            }
                                                        }
                                                        ?>
                                                </div>
                                                <div class="MaterialDropRightFooter">
                                                    <a class="btn orange clearBtnByUse" href="javascript:;" onclick="clearFilterByUse(this)">Clear</a>
                                                    <a class="btn ApplyBtn" href="javascript:;" onclick="filterbyUse()" >Apply</a>
                                                </div>
                                                <div style="clear: both;"></div>
                                            </div>
                                        </li>

                                    <?php
                                    }
                                }
                                ?>


                            </ul>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
        <!--  Material Page Left Filter End  -->

        <!--  IF   -->

        <?php
        $img_src = "";
        if(preg_match("/SRA3/",$details['CategoryName'])){
            $img_src = Assets."images/categoryimages/SRA3Sheets/colours/".$products[0]->ManufactureID.".png";
            if(!getimagesize($img_src)){
                $img_src = Assets."images/categoryimages/SRA3Sheets/".$details['CategoryImage']; 
            }
        }else if(preg_match("/A3/",$details['CategoryName'])){
            $img_src = Assets."images/categoryimages/A3Sheets/colours/".$products[0]->ManufactureID.".png";
            if(!getimagesize($img_src)){
                $img_src = Assets."images/categoryimages/A3Sheets/".$details['CategoryImage']; 
            }
        }else{
            $img_src = Assets."images/categoryimages/A4Sheets/colours/".$products[0]->ManufactureID.".png";
            if(!getimagesize($img_src))
            {
                $img_src = Assets."images/categoryimages/A4Sheets/".$details['CategoryImage']; 
            }
        }
        $newcatname = explode("-",$details['CategoryName']);
        $heading = $newcatname[0];
        $matcode = $this->home_model->getmaterialcode($products[0]->ManufactureID);
        $thumbnail = Assets."images/categoryimages/A4Sheets/euro_edges/".$matcode.".png";
        $dieCode = $products[0]->ManufactureID;
        ?>

        <div class="MaterialHeaderContentMain">
            <div class="MaterialWhiteBg" style="width: 100%;">
                <div class="row RowDefault">
                    <div class="MaterialHeaderImage">
                        <img src="<?php echo $img_src;?>" alt="" title="">
                    </div>

                    <div class="MaterialHeaderTitleCode">
                        <h2 class="TitleH2"><?php echo $heading;?></h2>
                        <span class="MaterialProductCode">Product Code: <?=ltrim($details['DieCode'],"1-")?></span>
                        <div class="MaterialHeaderContent">
                            <img src="<?php echo $thumbnail;?>"
                                 alt="" class="pull-left">
                            <p class="">Our innovative <span>DRY EDGE</span> label sheets, have a small 1mm strip of label material and adhesive removed from around the edge of the sheet, exposing the release liner and backing paper, creating a dry area that prevents problems associated with adhesive deposits on printer rollers. Enabling fater, problem free printing ofsheet labels. <br>
                                <a href="javascript:;" data-toggle="modal" data-target="#TableChart" class="MaterialViewSizeChartBtn">View size specification</a>
                            </p>
                            <!-- Modal -->
                            <div class="modal fade" id="TableChart" role="dialog">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content ChartTable">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <div class="modal-body">
                                            <div class="MaterialHeaderChartProductImg">
                                                <img src="<?=$img_src?>" alt="" title="">
                                                <div class="MaterialHeaderTableArrow"></div>
                                            </div>
                                            <div class="MaterialHeaderTable">
                                                <table class="table table-bordered table-hover">
                                                    <tbody>
                                                    <tr>
                                                        <td class="MaterialTableHeadingBold" width="25%">Label Width:</td>
                                                        <td width="25%" align="center"><?=$details['LabelWidth']?></td>
                                                        <td class="MaterialTableHeadingBold" width="25%">Labels Height:</td>
                                                        <td width="25%" align="center"><?=$details['LabelHeight']?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="MaterialTableHeadingBold" width="25%">Label Across:</td>
                                                        <td width="25%" align="center"><?=$details['LabelAcross']?></td>
                                                        <td class="MaterialTableHeadingBold" width="25%">Label Around:</td>
                                                        <td width="25%" align="center"><?=$details['LabelAround']?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="MaterialTableHeadingBold" width="25%">Top Margin:</td>
                                                        <td width="25%" align="center"><?=$details['LabelTopMargin']?></td>
                                                        <td class="MaterialTableHeadingBold" width="25%">Bottom Margin:</td>
                                                        <td width="25%" align="center"><?=$details['LabelBottomMargin']?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="MaterialTableHeadingBold" width="25%">Gap Across:</td>
                                                        <td width="25%" align="center"><?=$details['LabelGapAcross']?></td>
                                                        <td class="MaterialTableHeadingBold" width="25%">Gap Around:</td>
                                                        <td width="25%" align="center"><?=$details['LabelGapAround']?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="MaterialTableHeadingBold" width="25%">Left Margin:</td>
                                                        <td width="25%" align="center"><?=$details['LabelLeftMargin']?></td>
                                                        <td class="MaterialTableHeadingBold" width="25%">Right Margin:</td>
                                                        <td width="25%" align="center"><?=$details['LabelRightMargin']?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="MaterialTableHeadingBold" width="25%">Corner Radius:</td>
                                                        <td width="25%" align="center"><?=$details['LabelCornerRadius']?></td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="MaterialHeaderDownloadContent">
                        <span>Templates</span>
                        <ul>
                            <li>
                                <span>Copy will be here</span><br>

                                <a href="<?=base_url()."download/pdf/".$details['pdfFile'];?>?v=<?=time()?>" target="_blank"><i class="fa fa-file-pdf"></i> PDF </a></li>
                            <li>
                                <span>Copy will be here</span><br>
                                <a href="<?=Assets."images/office/word/".$details['WordDoc'];?>?v=<?=time()?>" target="_blank"><i class="fa fa-file-word"></i> MS Word</a>
                            </li>
                            <li>
                                <span>Copy will be here</span><br>
                                <a href="<?=base_url().'custom-label-tool/designer/'.$productid.'/'?>" target="_blank"><i class="fa fa-edit"></i> Label Designer</a>
                            </li>
                        </ul>

                    </div>

                    <div class="MaterialHeaderBadgeDownload">
                        <div class="MaterialHeaderBadge">
                            <a href="javascript:void(0);">
                                <img src="<?=Assets?>images/30-icon.png" alt="30 Days Moneyback Guarantee">
                            </a>
                            <p>If you are not 100% satisfied with your labels, return them to us within 30 days and we will refund your purchase. &nbsp;
                                <a href="javascript:;"><i class="fa fa-external-link-alt"></i>read more</a>
                            </p>
                        </div>
                    </div>
                    
                    <div class="MaterialHeaderISOImages">
                        <img src="<?=Assets?>images/ISO-logos.png" alt="ISO Logos" draggable="false">
                    </div>

                </div>
            </div>
            <div class="MaterialSeprator">&nbsp;</div>
        </div>
        <!--  Material Page Header End  -->

        <!--  Material Page Center Content Start  -->
        <div class="MaterialCenterContentMain">
            
            <div id="aa_loader_products" class="white-screen" style="display: none;background: #00000070;width: 69%;height: 100%;position: absolute;z-index: 999;top: 30px;">
                <div class="loading-gif text-center" style="top: 382px;z-index: 168;left: 40%;position: sticky;width: 46%;"> <img onerror="imgError(this);" src="https://www.aalabels.com/theme/site/images/loader.gif" class="image" style="width:160px; height:43px; "></div>
            </div>

            <div class="productsMainContainer">
                <?php include "allProductsSheets.php"; ?>
            </div>
            <div class="MaterialPageBanner">
                <p>
                    If you have a label shape and size requirement that you cannot find in our standard range and/or a
                    label application that we have not listed. Please provide the information requested and we will be
                    happy to provide you with a quote for your label.
                </p>

                <div class="LabelApplication">
                    <textarea placeholder="Label Application"></textarea>
                </div>
                <div class="LabelApplication">
                    <input type="email" placeholder="Email">
                </div>
                <div class="LabelApplicationSubmitButton">
                    <a href="javascript:;">Submit</a>
                </div>
            </div>


            <!-- Material Popup -->
            <div class="modal fade in" tabindex="-1" role="dialog" id="MaterialModalPopup">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button aria-label="Close" data-dismiss="modal" class="close" type="button"><span aria-hidden="true">×</span></button>
                            <h4 id="myModalLabel" class="modal-title">AA Labels Technical Specification - <span id="mat_code">PVUD</span> <a href="#myModalLabel" class="anchorjs-link"><span class="anchorjs-icon"></span></a></h4>
                        </div>
                        <div class="">
                            <div>
                                <div class="col-md-3 text-center"> <img onerror="imgError(this);" id="material_popup_img" src="https://www.aalabels.com/theme/site/images/material_images/Matt_White_Polyethylene_Permanent_Adhesive.png" alt="1 Circular Label per A4 sheet " title="1 Circular Label per A4 sheet " class="m-t-b-10 img-Sheet-material" width="46" height="46"> </div>
                                <div class="col-md-9">
                                    <div id="specs_loader" class="white-screen hidden-xs" style="display: none;">
                                        <div class="loading-gif text-center" style="top:26%;left:29%;"> <img onerror="imgError(this);" src="https://www.aalabels.com/theme/site/images/loader.gif" class="image" style="width:139px; height:29px; "> </div>
                                    </div>
                                    <div id="ajax_tecnial_specifiacation" class="specifiacation"><div>
                                        
                                    </div>
                                </div>
                                    <div class="bgGray p-l-r-10"> <small> This summary materials specification for this adhesive label is based on information obtained from the original material manufacturer and is offered in good faith in accordance with AA Labels terms and conditions to determine fitness for use as sheet labels (A4, A3 &amp; SRA3) produced by AA Labels. No guarantee is offered or implied. It is the user's responsibility to fully asses and/or test the label's material and determine its suitability for the label application intended. Measurements and test results on this label's material are nominal. In accordance with a policy of continuous improvement for label products the manufacturer and AA Labels reserves the right to amend the specification without notice. A <a href="https://www.aalabels.com/labels-materials/">full material specification</a> can be found in the Label Materials section accessed via the Home Page <br>
                                        Copyright© AA labels 2015</small> </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default MaterialModalButton" type="button">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Material Popup -->
        </div>
        <!--  Material Page Center Content End  -->

    </div>
    <!--  Material Page Content End  -->


</div>

<div class="modal fade pbreaks aa-modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content no-padding">
      <div class="panel no-margin">
        <div class="panel-heading">
          <h3 class="pull-left no-margin"> <b class="pull-left">VOLUME PRICE BREAKS
            <?=strtoupper($Paper_size)?>
            </b>
            <? if(strtolower($Paper_size) == 'a4 sheets'){?>
            <span class="label label-danger pull-left hppp-title-text">(Half Price Print Promotion off prices shown below)</span>
            <? }?>
            <a href="#myModalLabel" class="anchorjs-link"><span class="anchorjs-icon"></span></a> </h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-times-circle"></i></button>
          <div class="clear"></div>
        </div>
        <div class="panel-body">
          <div class="text-center">
            <div id="price_loader" class="white-screen hidden-xs" style="display:none;">
              <div class="loading-gif text-center" style="top:26%;left:29%;"> <img onerror='imgError(this);' src="<?=Assets?>images/loader.gif" class="image" style="width:139px; height:29px; "> </div>
            </div>
            <div class="table-res table-responsive" id="ajax_price_breaks"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



<script>
function filterbyProducts()
{
    var FBP = "";
    var FBPC = "";
    var FBAT = "";
    var filterUses = $(".filterUses").val();
    var chx = document.getElementsByClassName('FBP');
    var chx_pa = document.getElementsByClassName('FBAP');
    var checkboxCheckedCount = 0;
    var checkboxCheckedCountPc = 0; //printer compatibility
    var checkboxCheckedCountAt = 0; //adhesive type
    $('.MaterialFilterLeftProducts').removeClass("activeFilterClass");
    for (var i=0; i<chx_pa.length; i++) {
        if (chx_pa[i].type == 'checkbox' && chx_pa[i].checked) {

            var filter_type = $(chx_pa[i]).data('filter-type');
             if (filter_type === 'printer'){
                if(checkboxCheckedCountAt == 0)
                {
                    FBPC = chx_pa[i].value;
                }
                else
                {
                    FBPC += ","+chx_pa[i].value;
                }
                checkboxCheckedCountAt++;
                $(chx_pa[i]).parents('li').find('.MaterialFilterLeftProducts').addClass("activeFilterClass");
            }else if(filter_type === 'adhesive'){
                if(checkboxCheckedCountPc == 0)
                {
                    FBAT = chx_pa[i].value;
                }
                else
                {
                    FBAT += ","+chx_pa[i].value;
                }
                checkboxCheckedCountPc++;
                $(chx_pa[i]).parents('li').find('.MaterialFilterLeftProducts').addClass("activeFilterClass");
            }

        }
    }


    for (var i=0; i<chx.length; i++) {
        if (chx[i].type == 'checkbox' && chx[i].checked) {
            if(checkboxCheckedCount == 0)
            {
                FBP = chx[i].value;
            }
            else
            {
                FBP += ","+chx[i].value;
            }
            checkboxCheckedCount++;
           $(chx[i]).parents('li').find('.MaterialFilterLeftProducts').addClass("activeFilterClass");
        } 
    }

    $("#aa_loader_products").show();
    var categoryId = $(".categoryId").val();
    var showFavouritesProducts = false;
    var printingType = $(".printingType").val();
    var productid = $(".productid").val();

    if($('.favouritebyProducts').prop("checked") == true )
    {
        showFavouritesProducts = true;
    }
    
    $.ajax({
        url: base+'ajax/getFilteredProducts',
        type:"POST",
        async:"false",
        dataType: "html",
        data: {'showFavouritesProducts': showFavouritesProducts, "categoryId":categoryId, "printingType":printingType, "productid":productid, "FBU":FBP,"FBPC":FBPC,"FBAT":FBAT, "filterUses":filterUses},
        success: function(data){
            if(data != '')
            {
                data = $.parseJSON(data);
                $(".productsMainContainer").html(data.html);
            }
            $(document).ready(function(){
                $(".MaterialCenterContentMain .eachproductContainer:first-child .MaterialWhiteBg .MaterialCenterContentOuter .MaterialCenterContentInner .RowDefault .MaterialViewPrices .btn").click();
            });
            $("#aa_loader_products").hide();
        }
    });
}
function clearFilterByProducts(_this)
{
    $(_this).parents(".FBPParent").find('.FBP').each(function(i) {
        $(this).attr('checked',false);
    });
    filterbyProducts();
}
function clearFilterByPC(_this)
{
    $(_this).parents(".FBPParent").find('.FBPC').each(function(i) {
        $(this).attr('checked',false);
    });
    filterbyProducts();
}
function resetByProducts()
{
    $(".FBPParent").find('.FBP').each(function(i) {
            $(this).attr('checked',false);
    });
    $(".FBPParent").find('.FBPC').each(function(i) {
            $(this).attr('checked',false);
    });
    $('.favouritebyProducts').attr('checked',false);
    filterbyProducts();
}


function filterbyUse()
{
    var FBU = "";
    var filterUses = $(".filterUses").val();
    var chx = document.getElementsByClassName('FBU');

    $('.MaterialFilterLeftUse').removeClass("activeFilterClass");
    for (var i=0; i<chx.length; i++) {
        if (chx[i].type == 'radio' && chx[i].checked) {
           FBU = chx[i].value;
           $(chx[i]).parents('li').find('.MaterialFilterLeftUse').addClass("activeFilterClass");
        } 
    }

    $("#aa_loader_products").show();
    var categoryId = $(".categoryId").val();
    var showFavouritesProducts = false;
    var printingType = $(".printingType").val();
    var productid = $(".productid").val();

    if($('.favouriteByUse').prop("checked") == true )
    {
        showFavouritesProducts = true;
    }
    
    $.ajax({
        url: base+'ajax/getFilteredProducts',
        type:"POST",
        async:"false",
        dataType: "html",
        data: {'showFavouritesProducts': showFavouritesProducts, "categoryId":categoryId, "printingType":printingType, "productid":productid, "FBU":FBU, "filterUses":filterUses},
        success: function(data){
            if(data != '')
            {
                data = $.parseJSON(data);
                $(".productsMainContainer").html(data.html);
            }
            $(document).ready(function(){
                $(".MaterialCenterContentMain .eachproductContainer:first-child .MaterialWhiteBg .MaterialCenterContentOuter .MaterialCenterContentInner .RowDefault .MaterialViewPrices .btn").click();
            });
            $("#aa_loader_products").hide();
        }
    });
}



function clearFilterByUse(_this)
{
    $(_this).parents(".FBUParent").find('.FBU').each(function(i) {
            $(this).attr('checked',false);
    });
    filterbyUse();

}

function resetByUse()
{
    $(".FBUParent").find('.FBU').each(function(i) {
            $(this).attr('checked',false);
    });
    $('.favouriteByUse').attr('checked',false);

    filterbyUse();
}

function resetByPU()
{
    if($(".filterUses").val() == "byProduct"){
        resetByProducts();
    }else{
        resetByUse();
    }
}
</script>