<div >
                      <div class=" text-justify">
                        <div>
                          <h3>Face-Stock</h3>
                          <p>A gloss white Polypropylene film with thermo-sensitive coating (producing black imaging).</p>
                          <table class="table table-striped">
                            <tbody>
                              <tr>
                                <td class="w50">Basis Weight</td>
                                <td class="w50" >69 g/m²±10%</td>
                                <td class="w50" >ISO 536</td>
                              </tr>
                              <tr>
                                <td class="w50">Caliper</td>
                                <td class="w50" >76 µm   ±10%</td>
                                <td class="w50" ><p>ISO 534 </p></td>
                              </tr>
                              <tr>
                                <td class="w50">Smoothness (Face)</td>
                                <td class="w50" >min. 500 sec.</td>
                                <td class="w50" ><p>ISO 5627</p></td>
                              </tr>
                              <tr>
                                <td class="w50">Brightness (Face)</td>
                                <td class="w50" >min. 80%</td>
                                <td class="w50" ><p>ISO 2470</p></td>
                              </tr>
                              <tr>
                                <td class="w50">Image Colour	</td>
                                <td class="w50" >Black      </td>
                                <td class="w50" >Visual Inspection</td>
                              </tr>
                              <tr>
                                <td class="w50">Static Image Density</td>
                                <td class="w50" >min. 1.34</td>
                                <td class="w50" ><p>Macbeth Density</p></td>
                              </tr>
                              <tr>
                                <td class="w50">Background Density</td>
                                <td class="w50" >max. 0.12</td>
                                <td class="w50" ><p>Macbeth Density</p></td>
                              </tr>
                            </tbody>
                          </table>
                          <h3 >Adhesive</h3>
                          <p>A general purpose permanent rubber pressure sensitive adhesive with a good level of adhesion on a wide variety of substrates, including apolar, slightly rough and curved substrates. Particularly good performance at lower temperatures e.g. labelling of chilled products.</p>
                      
                        <h3 class="f-16 TextBlue">Performance data <small>(Typical Technical Values) </small></h3>
                          <table class="table table-striped">
                            <tbody>
                              <tr>
                                <td class="w50">Initial Tack </td>
                                <td class="w50" >22 N/25mm</td>
                                <td class="w50" >FINAT FTM 9 Glass</td>
                              </tr>
                              <tr>
                                <td class="w50">Peel Adhesion 90°</td>
                                <td class="w50">11 N/25mm</td>
                                <td class="w50">FINAT FTM 2 St. St.</td>
                              </tr>
                              <tr>
                                <td class="w50">Min. Application Temp.</td>
                                <td class="w50">0° C</td>
                                <td class="w50">&nbsp;</td>
                              </tr>
                              <tr>
                                <td class="w50">Service Temperature</td>
                                <td class="w50">-40° C to 70° C    </td>
                                <td class="w50"></td>
                              </tr>
                            </tbody>
                          </table>
                              
                          
						 <h3 >Release Liner</h3>
                          <p>A brown SC <small>(Super Calendered)</small> glassine paper release liner. </p>
                          <table class="table table-striped">
                            <tbody>
                              <tr>
                                <td class="w50">Basis Weight</td>
                                <td class="w50" >57 g/m²	±10%</td>
                                <td class="w50" >ISO 536</td>
                              </tr>
                              <tr>
                                <td class="w50">Caliper</td>
                                <td class="w50" >51 µm   ±10%</td>
                                <td class="w50" ><p>ISO  534 </p></td>
                              </tr>
                            </tbody>
                          </table>
                        
                          <h3 >Applications and use </h3>
                          <p>This face material is a designed for a durable synthetic tag material with enhanced tear resistance and high sensitivity for use in a wide range of applications, including commercial tagging, wristbands, sport/game licensing, amusement pass adn ski-lift tickets where short life, or low contamination is common.</p>
                          <p>There are many other commercial, component, equipment and industrial applications for short-life, durable informational labels.</p>
                          
<h3>Conversion and printing</h3>
                          <p>This thermo-sensitive product is designed for use in thermal printing systems at printing speeds up to 200mm/sec. The product can also be converted by all conventional roll conversion technologies including flexographic and UV letter-press. However due to the thermographic properties exposure over 50°C may cause premature imaging or discolouration. Also inks containing alcohol or volatile organic solvents may cause discolouration of the thermo-sensitive coating. It is always advisable to test inks and varnishes before conversion.</p>
                          
<h3 >Approvals</h3>
                          <p>The adhesive complies with the European food directives and legislation FDA 21; CFR 175, 105 and the German recommendations XXI as published by BfR (Bundesinstitut fur Risikobewertung) the German Federal Institute for Risk Assessment. Both of which state that the adhesive can be used in direct contact with dry, moist and non-fatty foodstuffs with a reduction factor 2. However according to the FDA regulations the adhesive must be separated from the foodstuffs by a functional barrier.</p>
                          
                          
<h3 >Shelf Life</h3>
<p>One year under storage conditions as defined by Premier Coating & Converters Ltd 20° - 25° C and 40 – 50% RH.</p>
</div>
                      </div>
                    </div>